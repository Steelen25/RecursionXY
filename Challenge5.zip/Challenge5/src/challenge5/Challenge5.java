/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 * (Use Javadoc tags to document your code too.
 *
 * @Zachariah Nelson (3645888)
 *  
 *  Title:challenge4  
* 
* Semester: COP3804 - Spring 2022    
* Lecturer's Name:  Cristy Charters
*   Description of Program’s Functionality: change all x's in a string the user gives to y's and print out original and new string.
*/
package challenge5;

import java.util.Scanner;

/**
 *
 * @author zsnel
 */
public class Challenge5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String userWord, nextWord, str;
        Scanner scnr = new Scanner(System.in);
        do
        {
            System.out.println("Plese enter a word you would like to use: "); // asks user to enter a word
            userWord = scnr.next(); //grabs user word
            str = userWord; // hold original word in string
            System.out.println(str); // prints the original word
            System.out.println(changeXY(str));// prints changed word
            System.out.println("Would you like to enter another word? "); 
            nextWord = scnr.next(); //grabs users answer
        }while(nextWord.equalsIgnoreCase("yes")); // if user said yes repeats the loop
    }
    public static String changeXY(String str)//recursive method
    {
        if( str == "") // base case (alwasy first)
        {
            return str;
        }
        else if(str.charAt(0) == 'x') //if it finds an x it changes it to a y then calls the "shorter" word
        {
            return 'y' + changeXY(str.substring(0 + 1));
        }                
        else
            return str.charAt(0) + changeXY(str.substring(0 + 1)); // makes the word shorter for the next call                                 
    }
}
